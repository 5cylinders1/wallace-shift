# Homepage logo sequence

The production homepage uses pearl, graphite, ice blue and deep petrol. The
existing black-to-pearl statement wipe now uses petrol for “unforgettable.”
Shared palette values and measured solid-color contrast are documented in
`brand-palette.md`.

## Sequence

- The original opening copy and enquiry card remain over the glass water
  hero. Touch-first/mobile visitors retain the existing MP4 hero.
- The actual two-part `ws_logo.glb` enters from beyond the right edge alongside
  the services heading. Its upper edge pins directly beneath navigation first;
  the next 360–720px of scroll brings the model into place, with no timed entrance
  or fade. Stopping or reversing scroll stops or reverses the same pose.
  The services mark is 160–240px wide and rests 75px beyond the measured
  headline's right edge. Its bottom follows the last line's measured baseline,
  using the actual GLB height to position the model. The services pose faces
  straight forward with a pale silver finish, subdued bevels, and a faint
  broad reflection. The heading band is borderless graphite with pearl type
  and ice-blue supporting text. It returns smoothly to the existing process
  composition as that section enters; later scenes retain their sizes.
  Service rows and their destination
  links move underneath it. Bottom clearance lets them pass completely
  before the heading releases. The logo stays in the same visual container.
- Service bars retain the original diagonal video reveals, oversized TRUST,
  FLOW and TIME words, and their individual line animations. The homepage
  uses separately graded ice-blue/graphite versions of the original films;
  other callers keep the original assets. Scroll selection follows the visible
  area below the pinned heading, with hover and keyboard focus overrides.
  Inactive/offscreen videos pause. Mobile reserves space for all three panels
  to prevent layout jumps; reduced motion shows the matching still posters.
- The process now precedes the quiz. The central cut illuminates during
  “Find the friction.” The authored halves separate and turn during “Make
  the shift,” changing from chrome toward crystal. “Launch with momentum”
  completes the turn, reassembles the original silhouette, and settles its
  interior light. Resting motion comes from slow reflections, not spinning.
- The quiz retains its questions, recommendations, keyboard behavior and
  contact handoff. Its retired spotlight is replaced by the shared logo.
- The closing form and footer share a quieter logo and water composition.
  The water samples the actual posed logo; the old horizon video is omitted
  only for this homepage composition. Copy and form controls remain above
  the decorative render layer.

## Implementation boundaries

`HomeJourney` owns the semantic layout and a mutable pose ref. Native sticky
positioning holds the stage; `journeyDirector` samples absolute scroll position
for reversible transforms, including restored scroll positions. Resize and
upstream hero refresh events rebase its measurements.

`LogoJourneyScene` is loaded only near the desktop sequence. It owns one
transparent Canvas, a private parse of the existing GLB, and its own materials
and reflection target. DPR is capped at 1.4 and the closing reflection at
512px. Frame scheduling stops outside the visible sequence and in a hidden
tab. The loading silhouette follows the same pose until the first successful
frame. Model/load/context failures use static content without disabling the
desktop services heading's pin. The HTML Canvas fallback is inert because
React Three Fiber mounts it even when WebGL succeeds; only real rendering
failures activate the fallback layout.

Mobile, coarse-pointer, reduced-motion and failed-WebGL modes retain all copy,
quiz controls, enquiry fields and links without this Canvas. The process uses
shorter ordinary-flow steps in those modes. No new logo export is required.

## Preserved work

- `/experiments/water-hero` retains all of its material options and original
  reveal, controls and scene choreography.
- `/experiments/pit-stop` preserves the previous pit-stop presentation,
  isolated from the production palette and marked noindex/nofollow.
- `archive/homepage-2026-09-10/README.md` documents the retired media and
  source archives, their original paths and checksums. Copies are saved
  outside `public`; originals still referenced by other pages/experiments
  remain in place. The archive is excluded from deployment.
- Restored services media lives in `public/media/services/`. The additive
  `archive/homepage-2026-09-10/service-media-ice-grade/` directory records
  the LUT, reproduction commands, metadata and original/derivative checksums.
  These are local color grades of existing Runway films, not new generations.

## Verification and remaining visual review

The existing checks cover the opening hero, material contracts, statement
wipe, forms and experiment behavior. New checks cover scroll coordinates,
reverse seeking, process phases, static/server markup, lazy dependencies,
GLB vertices/normals/reassembly, disposal, and reflection renderer state.
These checks and a production build do not establish browser/GPU appearance.

Browser access was authorized again on September 10. The services correction
was visually verified locally at 1280×720 and 1728×960: the GLB stays loaded,
enters from offscreen right after the heading pins, rests when scrolling stops,
and reverses with scrolling. The heading remains at the navigation's measured
bottom (83px at those sizes), the rows pass underneath, and it releases only
after the rows and links clear. The previously broken state was reproduced at
1280×720 before the correction: the model silently fell back and the heading
scrolled away. At 390×844, mobile retains ordinary flow, no entrance runway,
and no journey Canvas, with no horizontal overflow.

All 252 automated checks and the production build pass. Lint has no errors;
the existing pit-stop Fast Refresh warning and large shared 3D chunk build
warning remain. A healthy-Canvas regression check mounts its HTML fallback
and verifies that doing so does not report a renderer failure.

The full process choreography, quiz-to-contact handoff, final water reflection,
reduced-motion appearance and deliberately failed GLB load remain outside this
focused visual review; their automated checks are separate from browser evidence.
The subsequent services spacing adjustment was checked at the same desktop
sizes: about 40% smaller than before and a 75px gap from the headline.
All 16 journey/renderer checks, build and lint pass for that adjustment.
The follow-up baseline/black-finish adjustment was also visually checked at
1280×720 and 1728×960, with no browser rendering errors. Its 17 focused checks
include material restoration for the later scenes; build and lint pass with
the existing warnings noted above.
No commit or deployment is performed by this change.

The service-media restoration was visually checked at 1280×720, 1728×960
and 390×844. The diagonal panels, oversized words and videos render; video
playback advances while active and pauses after another panel takes over.
Forward/reverse scrolling and keyboard focus switch panels. The heading
remains at 83px on desktop, and its text/GLB cover the passing rows correctly.
Mobile retains all three panels without horizontal overflow or a journey
Canvas. There were no browser errors; the existing Three.Clock deprecation
warning remains. Reduced-motion playback is verified separately by automated
checks, not by changing the browser's motion preference.
For this restoration, the full existing suite passed 254 checks; four additional
playback lifecycle checks passed separately (258 total). Build and lint passed
with the existing warnings described above. Original public and archive media
checksums remain unchanged.

The subsequent services header inversion uses graphite with pearl type and a
pale silver GLB, with neither a top nor bottom section border. Desktop and
mobile appearance were verified at 1280×720 and 390×844; the sticky position,
baseline alignment and restored videos remain intact. Switching back from
mobile also clears the panels' temporary height and obsolete reveal animations.
