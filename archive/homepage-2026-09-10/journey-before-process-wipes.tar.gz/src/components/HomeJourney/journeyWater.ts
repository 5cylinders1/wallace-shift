import { HalfFloatType, LinearFilter, Mesh, NoToneMapping, PlaneGeometry,
  ShaderMaterial, Vector2, WebGLRenderTarget, Color, type Camera, type Scene, type WebGLRenderer } from 'three'

/** One small capture of the actual, currently posed logo. The reflection
 * stays joined to its measured base, then softens into quiet surface ripples. */
export function createJourneyWater() {
  const target = new WebGLRenderTarget(2, 2, {
    type: HalfFloatType, minFilter: LinearFilter, magFilter: LinearFilter,
    depthBuffer: true, stencilBuffer: false,
  })
  const material = new ShaderMaterial({
    transparent: true, depthTest: false, depthWrite: false,
    uniforms: {
      uLogo: { value: target.texture }, uWater: { value: 0 }, uBase: { value: .32 },
      uTime: { value: 0 }, uTexel: { value: new Vector2(.001, .001) },
    },
    vertexShader: `varying vec2 vUv; void main() { vUv = uv; gl_Position = vec4(position.xy, .999, 1.0); }`,
    fragmentShader: /* glsl */ `
      uniform sampler2D uLogo;
      uniform float uWater, uBase, uTime;
      uniform vec2 uTexel;
      varying vec2 vUv;
      void main() {
        float below = uBase - vUv.y;
        float depth = max(0.0, below);
        float waterMask = smoothstep(-.004, .015, below);
        float ripple = sin(depth * 360.0 - uTime * .55 + sin(vUv.x * 18.0) * 2.0)
          + sin(depth * 690.0 + uTime * .37) * .36;
        vec2 sampleUv = vec2(vUv.x + ripple * (.0008 + depth * .018),
          uBase + depth * (1.0 + depth * .55));
        vec2 spread = uTexel * (1.0 + depth * 32.0);
        vec4 reflection = texture2D(uLogo, sampleUv) * .4;
        reflection += texture2D(uLogo, sampleUv + vec2(spread.x, 0.0)) * .2;
        reflection += texture2D(uLogo, sampleUv - vec2(spread.x, 0.0)) * .2;
        reflection += texture2D(uLogo, sampleUv + vec2(0.0, spread.y)) * .1;
        reflection += texture2D(uLogo, sampleUv - vec2(0.0, spread.y)) * .1;
        float valid = step(0.0, sampleUv.x) * step(sampleUv.x, 1.0)
          * step(0.0, sampleUv.y) * step(sampleUv.y, 1.0);
        float reflectionGain = waterMask * valid * exp(-depth * 6.5) * .30;
        float pocket = .5 + .24 * sin(vUv.x * 13.0 + uTime * .06)
          + .18 * sin(vUv.x * 29.0 - uTime * .035);
        float farFog = exp(-pow((below + .015 + sin(vUv.x * 9.0) * .012) / .055, 2.0));
        float nearFog = exp(-pow((below - .035 + sin(vUv.x * 17.0 + uTime * .04) * .02) / .025, 2.0));
        float fog = (farFog * .085 + nearFog * .035) * pocket;
        vec3 color = vec3(.010, .016, .020) * waterMask;
        color += reflection.rgb * reflectionGain;
        color += vec3(.20, .28, .32) * fog;
        float alpha = waterMask * .48 + reflection.a * reflectionGain + fog;
        gl_FragColor = vec4(color, min(.72, alpha) * uWater);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }
    `,
  })
  const geometry = new PlaneGeometry(2, 2)
  const mesh = new Mesh(geometry, material)
  mesh.name = 'JourneyQuietWater'
  mesh.frustumCulled = false
  mesh.renderOrder = -100
  const clearColor = new Color()
  let width = 0, height = 0
  return {
    mesh,
    update(renderer: WebGLRenderer, scene: Scene, camera: Camera,
      viewportWidth: number, viewportHeight: number, base: number, water: number, time: number) {
      mesh.visible = water > .001
      material.uniforms.uWater.value = water
      material.uniforms.uBase.value = base
      material.uniforms.uTime.value = time
      if (water <= .001) return
      const fit = Math.min(1, 512 / Math.max(viewportWidth, viewportHeight))
      const nextWidth = Math.max(2, Math.round(viewportWidth * fit))
      const nextHeight = Math.max(2, Math.round(viewportHeight * fit))
      if (width !== nextWidth || height !== nextHeight) {
        width = nextWidth; height = nextHeight
        target.setSize(width, height)
        material.uniforms.uTexel.value.set(1 / width, 1 / height)
      }
      const previousTarget = renderer.getRenderTarget()
      const previousToneMapping = renderer.toneMapping
      const previousAlpha = renderer.getClearAlpha()
      renderer.getClearColor(clearColor)
      mesh.visible = false
      try {
        renderer.toneMapping = NoToneMapping
        renderer.setRenderTarget(target)
        renderer.setClearColor(0, 0)
        renderer.clear()
        renderer.render(scene, camera)
      } finally {
        renderer.setRenderTarget(previousTarget)
        renderer.toneMapping = previousToneMapping
        renderer.setClearColor(clearColor, previousAlpha)
        mesh.visible = true
      }
    },
    dispose() { target.dispose(); geometry.dispose(); material.dispose() },
  }
}
