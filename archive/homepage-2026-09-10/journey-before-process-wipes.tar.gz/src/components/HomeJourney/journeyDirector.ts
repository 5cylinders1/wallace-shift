/** A viewport-relative pose shared with the lazily loaded renderer. */
export interface JourneyFrame {
  visible: number
  x: number
  y: number
  scale: number
  yaw: number
  split: number
  partTurn: number
  finish: number
  charge: number
  water: number
  servicesSurface: number
}

export interface JourneyLayout {
  viewportHeight: number
  viewportWidth: number
  headerOffset: number
  servicesTop: number
  servicesHeaderHeight: number
  servicesHeadingRight: number
  servicesHeadingBaseline: number
  entranceDistance: number
  processTop: number
  steps: { top: number; height: number }[]
  quizTop: number
  closingTop: number
  end: number
}

const clamp = (value: number) => Math.min(1, Math.max(0, value))
const mix = (a: number, b: number, t: number) => a + (b - a) * t
export const journeyEase = (value: number) => {
  const t = clamp(value)
  return t * t * (3 - 2 * t)
}
const phase = (scroll: number, start: number, length: number) => journeyEase((scroll - start) / Math.max(1, length))

export const initialJourneyFrame: JourneyFrame = {
  visible: 0, x: 1.5, y: 0.4, scale: 0.14, yaw: 0,
  split: 0, partTurn: 0, finish: 0, charge: 0.08, water: 0, servicesSurface: 1,
}

/** Absolute scroll position is the only clock for the transformations.
 * Seeking, reverse scrolling and restored scroll positions share one pose. */
export function sampleJourneyFrame(scroll: number, layout: JourneyLayout): JourneyFrame {
  const h = Math.max(1, layout.viewportHeight)
  const w = Math.max(1, layout.viewportWidth)
  // The upper rule pins beneath navigation first. The following scroll
  // runway brings the GLB in before the service rows reach that header.
  const entry = phase(scroll, layout.servicesTop - layout.headerOffset, layout.entranceDistance)
  const process = phase(scroll, layout.processTop - h * 0.8, h * 0.8)
  const quiz = phase(scroll, layout.quizTop - h * 0.65, h * 0.65)
  const closing = phase(scroll, layout.closingTop - h * 0.65, h * 0.65)
  const beats = layout.steps.map(step => phase(scroll, step.top - h * 0.45, step.height * 0.72))
  const [find = 0, make = 0, launch = 0] = beats
  const headingBaseline = Math.max(layout.headerOffset, layout.servicesTop - scroll) + layout.servicesHeadingBaseline
  // Before the visual itself pins, its local origin is still below the
  // viewport top. Avoid applying that entering-section offset twice.
  const visualTop = Math.max(0, layout.servicesTop - scroll)
  // During services this is the mark's bottom anchor. The renderer offsets
  // its center using the loaded GLB's actual height, not an estimated ratio.
  const headingY = 1 - 2 * (headingBaseline - visualTop) / h
  // Anchor this smaller mark to the rendered headline, not the viewport's
  // right-hand column. Later sections retain their existing composition.
  const servicesWidth = Math.min(240, Math.max(160, w * 0.14))
  const servicesX = (layout.servicesHeadingRight + 75 + servicesWidth / 2) * 2 / w - 1
  const restingX = mix(mix(servicesX, 0.53, process), 0.61, quiz)
  const restingScale = mix(mix(servicesWidth / w, 0.23, process), 0.21, quiz)
  // A shallow laptop viewport needs a smaller closing mark below the copy.
  // Preserve its proportions rather than cropping it at the waterline.
  const shortViewport = 1 - journeyEase((h - 650) / 300)
  const closingScale = Math.min(.22, h * .25 / (Math.max(1, layout.viewportWidth) * .549))
  return {
    visible: scroll + h > layout.servicesTop && scroll < layout.end ? 1 : 0,
    x: mix(mix(1.48, restingX, entry), -0.52, closing),
    y: mix(mix(headingY, -0.03, process), mix(-0.1, -0.48, shortViewport), closing),
    scale: mix(restingScale, closingScale, closing),
    yaw: 0.08 * process * (1 - closing),
    split: 0.22 * make * (1 - launch),
    partTurn: Math.PI * (make + launch),
    finish: 0.65 * make + 0.35 * launch,
    charge: mix(0.08 + Math.sin(Math.PI * find) * 0.65 + make * 0.13 + Math.sin(Math.PI * launch) * 0.5, 0.12, quiz),
    water: closing,
    servicesSurface: 1 - process,
  }
}
