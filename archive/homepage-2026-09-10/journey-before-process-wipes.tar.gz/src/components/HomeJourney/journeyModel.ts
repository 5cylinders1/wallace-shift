import { Box3, Color, Group, Matrix4, Mesh, Texture, Vector3,
  type Material, type MeshPhysicalMaterial, type Object3D } from 'three'
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js'
import { createLogoChromeMaterial, logoChromeUniforms } from '../experiments/water-hero/logoChrome'
import { createOpeningFrame } from '../experiments/water-hero/logoOpening'
import { NODE_NAMES, WS_LOGO_URL } from '../experiments/water-hero/waterHeroConfig'

const DARK_FACE = new Color().setRGB(.065, .081, .10)
const SERVICES_FACE = new Color('#dce5e8')
const CRYSTAL_FACE = new Color().setRGB(.40, .52, .60)
const COOL_LIGHT = new Color().setRGB(.64, .84, 1)

function disposeGraph(root: Object3D) {
  const geometries = new Set<Mesh['geometry']>()
  const materials = new Set<Material>()
  const textures = new Set<Texture>()
  root.traverse(child => {
    if (!(child instanceof Mesh)) return
    geometries.add(child.geometry)
    for (const material of Array.isArray(child.material) ? child.material : [child.material]) {
      materials.add(material)
      for (const value of Object.values(material)) if (value instanceof Texture) textures.add(value)
    }
  })
  geometries.forEach(geometry => geometry.dispose())
  materials.forEach(material => material.dispose())
  textures.forEach(texture => texture.dispose())
}

/** Private parse, not the experiment's cached graph. Authored geometry,
 * normals and transforms are retained; presentation pivots wrap each part. */
export function prepareJourneyModel(scene: Object3D) {
  scene.updateMatrixWorld(true)
  const authoredRoot = scene.getObjectByName(NODE_NAMES.root)
  const parts = [scene.getObjectByName(NODE_NAMES.left), scene.getObjectByName(NODE_NAMES.right)]
  if (!authoredRoot || parts.some(part => !part || !part.parent)) {
    throw new Error('The journey logo requires WS_Logo, WS_Left and WS_Right.')
  }
  for (const part of parts) {
    let ancestor = part!.parent
    while (ancestor && ancestor !== authoredRoot) ancestor = ancestor.parent
    if (!ancestor) throw new Error('The journey logo halves must remain beneath WS_Logo.')
  }
  const bounds = new Box3().setFromObject(scene)
  const size = bounds.getSize(new Vector3())
  const center = bounds.getCenter(new Vector3())
  if (size.x <= 0 || !Number.isFinite(size.x)) throw new Error('The journey logo has no measurable width.')
  const scale = 1 / size.x
  const materials: MeshPhysicalMaterial[] = []
  const originals = new Set<Material>()
  scene.traverse(child => {
    if (!(child instanceof Mesh)) return
    const frame = createOpeningFrame(child, authoredRoot)
    const source = Array.isArray(child.material) ? child.material : [child.material]
    const owned = source.map(material => {
      originals.add(material)
      const next = createLogoChromeMaterial(material, frame, child.geometry)
      next.name = 'HomepageJourney_ChromeCrystal'
      next.transparent = true
      next.roughness = .24
      next.clearcoat = .55
      next.clearcoatRoughness = .25
      next.iridescence = .05
      next.iridescenceIOR = 1.3
      next.iridescenceThicknessRange = [170, 300]
      next.envMapIntensity = .5
      logoChromeUniforms(next)!.uChromeSeamColor.value.copy(COOL_LIGHT)
      const crystal = { value: 0 }
      const servicesSurface = { value: 0 }
      next.userData.journeyCrystal = crystal
      next.userData.journeyServicesSurface = servicesSurface
      const compile = next.onBeforeCompile
      next.onBeforeCompile = (shader, renderer) => {
        compile(shader, renderer)
        shader.uniforms.uJourneyCrystal = crystal
        shader.uniforms.uJourneyServicesSurface = servicesSurface
        shader.vertexShader = shader.vertexShader
          .replace('#include <common>', '#include <common>\nvarying vec3 vJourneyAxis;')
          .replace('#include <beginnormal_vertex>', '#include <beginnormal_vertex>\nvJourneyAxis = normalize(normalMatrix * vec3(0.0, 1.0, 0.0));')
        shader.fragmentShader = shader.fragmentShader
          .replace('#include <common>', '#include <common>\nuniform float uJourneyCrystal;\nuniform float uJourneyServicesSurface;\nvarying vec3 vJourneyAxis;')
          .replace('#include <opaque_fragment>', /* glsl */ `
            // A second dielectric interface gives the crystal volume. Both
            // interfaces use the same soft photographic environment.
            vec3 journeyRear = vec3(0.0);
            #if defined(USE_ENVMAP) && defined(ENVMAP_TYPE_CUBE_UV)
              vec3 axis = normalize(vJourneyAxis);
              axis *= dot(axis, normal) < 0.0 ? -1.0 : 1.0;
              vec3 inside = refract(-normalize(vViewPosition), normal, 1.0 / 1.48);
              vec3 rearNormal = normalize(2.0 * dot(normal, axis) * axis - normal);
              journeyRear = getIBLRadiance(-inside, rearNormal, max(.25, roughness));
            #endif
            float journeyEdge = pow(1.0 - chromeNoV, 2.0);
            vec3 journeyCrystal = totalSpecular + journeyRear * vec3(.13, .18, .20)
              * (.30 + journeyEdge * .70) + chromeStudio * .18
              + vec3(.014, .026, .037) * (.40 + chromeFace * .60) + chromeSeam;
            outgoingLight = mix(outgoingLight, journeyCrystal, uJourneyCrystal);
            // Pale silver separates the services mark from its dark heading
            // band. Broad reflected light gently describes the face, with
            // a darker edge plane and bounded highlights instead of white rims.
            float journeyServicesRadiance = dot(max(outgoingLight, vec3(0.0)),
              vec3(.2126, .7152, .0722));
            float journeyServicesHighlight = .18 *
              (1.0 - exp(-journeyServicesRadiance * 1.8));
            vec3 journeyServicesBody = vec3(.64, .70, .73) * mix(.55, 1.0, chromeFace)
              + vec3(.96, .99, 1.0) * journeyServicesHighlight
              + chromeCard * chromeFace * .16;
            outgoingLight = mix(outgoingLight, journeyServicesBody, uJourneyServicesSurface);
            #include <opaque_fragment>
          `)
      }
      next.customProgramCacheKey = () => 'homepage-journey-chrome-crystal-services-v3'
      materials.push(next)
      return next
    })
    child.material = Array.isArray(child.material) ? owned : owned[0]
    child.castShadow = child.receiveShadow = false
  })
  originals.forEach(material => material.dispose())

  const pivots = parts.map(part => {
    const parent = part!.parent!
    const midpoint = new Box3().setFromObject(part!).getCenter(new Vector3())
    parent.worldToLocal(midpoint)
    const pivot = new Group()
    pivot.name = `${part!.name}_JourneyPivot`
    pivot.position.copy(midpoint)
    parent.add(pivot)
    pivot.add(part!)
    part!.position.sub(midpoint)
    return { pivot, position: midpoint.clone() }
  })
  const orientation = new Group()
  orientation.rotation.x = Math.PI / 2
  orientation.scale.setScalar(scale)
  orientation.position.copy(center.applyMatrix4(new Matrix4().makeRotationX(Math.PI / 2)).multiplyScalar(-scale))
  orientation.add(scene)
  const rig = new Group()
  rig.add(orientation)
  let disposed = false

  return {
    rig,
    height: size.z * scale,
    materials,
    setEnvironment(texture: Texture) {
      for (const material of materials) {
        material.envMap = texture
        material.needsUpdate = true
      }
    },
    update(finish: number, charge: number, split: number, partTurn: number, visible: number, time: number, servicesSurface = 0) {
      const services = Number.isFinite(servicesSurface) ? Math.max(0, Math.min(1, servicesSurface)) : 0
      pivots.forEach(({ pivot, position }, index) => {
        const direction = index === 0 ? -1 : 1
        pivot.position.copy(position)
        pivot.position.x += direction * split / (2 * scale)
        // Native Z becomes upright -Y after the shared quarter turn.
        pivot.rotation.z = -direction * partTurn
      })
      for (const material of materials) {
        material.color.copy(DARK_FACE).lerp(CRYSTAL_FACE, finish).lerp(SERVICES_FACE, services)
        material.metalness = (.94 - finish * .80) * (1 - services) + .97 * services
        material.roughness = (.24 - finish * .035) * (1 - services) + .36 * services
        material.clearcoat = (.55 + finish * .35) * (1 - services) + .08 * services
        material.clearcoatRoughness = .25 + services * .13
        material.envMapIntensity = .5 - services * .18
        material.iridescence = (.05 + finish * .13) * (1 - services)
        material.opacity = visible * (1 - finish * .08)
        // A softly luminous crystal interior; no white LED plate or texture.
        material.emissive.setRGB(.045, .074, .095).multiplyScalar(finish)
        material.userData.journeyCrystal.value = finish
        material.userData.journeyServicesSurface.value = services
        const uniforms = logoChromeUniforms(material)!
        uniforms.uChromeTime.value = time
        uniforms.uChromeSeamIntensity.value = (.05 + charge * 1.4) * (1 - services)
        uniforms.uChromeUnderwater.value = 0
      }
    },
    dispose() {
      if (disposed) return
      disposed = true
      // The PMREM environment is owned by the renderer, not this graph.
      materials.forEach(material => { material.envMap = null })
      disposeGraph(scene)
      rig.clear()
    },
  }
}

export type JourneyModel = ReturnType<typeof prepareJourneyModel>

export async function loadJourneyModel(signal: AbortSignal): Promise<JourneyModel> {
  signal.throwIfAborted()
  const response = await fetch(WS_LOGO_URL, { signal })
  if (!response.ok) throw new Error(`Could not load journey logo (${response.status}).`)
  const buffer = await response.arrayBuffer()
  signal.throwIfAborted()
  const gltf = await new GLTFLoader().parseAsync(buffer, '/models/')
  if (signal.aborted) {
    disposeGraph(gltf.scene)
    signal.throwIfAborted()
  }
  try {
    return prepareJourneyModel(gltf.scene)
  } catch (error) {
    disposeGraph(gltf.scene)
    throw error
  }
}
