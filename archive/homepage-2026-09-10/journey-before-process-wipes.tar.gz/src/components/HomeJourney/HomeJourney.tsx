import { Component, Suspense, lazy, useEffect, useRef, useState, useSyncExternalStore, type ReactNode } from 'react'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { approach, services } from '../../content/siteConfig'
import { renderLines } from '../../lib/textLines'
import { ContactCta } from '../ContactCta/ContactCta'
import { PageLink } from '../PageLink/PageLink'
import { ShiftQuiz } from '../ShiftQuiz/ShiftQuiz'
import { SiteFooter } from '../SiteFooter/SiteFooter'
import { getInteractiveHomeHeroSnapshot, getStaticHomeHeroSnapshot, subscribeInteractiveHomeHero } from '../Hero/homeHeroDisplay'
import { initialJourneyFrame, sampleJourneyFrame, type JourneyFrame, type JourneyLayout } from './journeyDirector'
import { JourneyServiceRows } from './JourneyServiceRows'
import './HomeJourney.css'

const LogoJourneyScene = lazy(() => import('./LogoJourneyScene'))

class SceneBoundary extends Component<{ children: ReactNode; onFailure: () => void }, { failed: boolean }> {
  state = { failed: false }
  static getDerivedStateFromError() { return { failed: true } }
  componentDidCatch(error: Error) {
    console.error('[HomeJourney] Scene failed to load', error)
    this.props.onFailure()
  }
  render() { return this.state.failed ? null : this.props.children }
}

function JourneyVisual({ frame, nearby, onFailure }: {
  frame: { current: JourneyFrame }; nearby: boolean; onFailure: () => void
}) {
  const [ready, setReady] = useState(false)
  return <div className="home-journey__visual" aria-hidden="true">
    {!ready && <img className="home-journey__loading-mark" src="/brand/wallace-shift-logo-black.svg" alt="" width="240" height="140" />}
    {nearby && <SceneBoundary onFailure={onFailure}>
      <Suspense fallback={null}><LogoJourneyScene frame={frame} onFailure={onFailure} onReady={() => setReady(true)} /></Suspense>
    </SceneBoundary>}
  </div>
}

const processPhases = ['Illuminate', 'Reshape', 'Resolve']

/** One production-only visual spans the story. All copy and forms remain
 * native DOM, with a complete static layout when motion/WebGL is unavailable. */
export function HomeJourney() {
  const rootRef = useRef<HTMLDivElement>(null)
  const interactive = useSyncExternalStore(subscribeInteractiveHomeHero, getInteractiveHomeHeroSnapshot, getStaticHomeHeroSnapshot)
  const [nearby, setNearby] = useState(false)
  const [failed, setFailed] = useState(false)
  const frame = useRef({ ...initialJourneyFrame })
  const live = interactive && !failed

  useEffect(() => {
    const root = rootRef.current
    if (!root || !live) return
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) { setNearby(true); observer.disconnect() }
    }, { rootMargin: '600px 0px' })
    observer.observe(root)
    return () => observer.disconnect()
  }, [live])

  useEffect(() => {
    const root = rootRef.current
    if (!root || !interactive) return
    const section = root.querySelector<HTMLElement>('.journey-services')!
    const heading = root.querySelector<HTMLElement>('.journey-services__header')!
    const headingText = root.querySelector<HTMLElement>('#journey-services-heading')!
    const baseline = root.querySelector<HTMLElement>('.journey-services__baseline')!
    const entrance = root.querySelector<HTMLElement>('.journey-services__entrance')!
    const process = root.querySelector<HTMLElement>('.journey-process')!
    const steps = Array.from(root.querySelectorAll<HTMLElement>('.journey-process__step'))
    const quiz = root.querySelector<HTMLElement>('#shift-finder')!
    const closing = root.querySelector<HTMLElement>('.home-journey__closing')!
    let pending = 0
    let layout: JourneyLayout
    const measure = () => {
      const scroll = window.scrollY
      const top = (element: HTMLElement) => element.getBoundingClientRect().top + scroll
      layout = {
        viewportHeight: window.innerHeight,
        viewportWidth: window.innerWidth,
        headerOffset: parseFloat(getComputedStyle(heading).top) || 0,
        servicesTop: top(section), servicesHeaderHeight: heading.offsetHeight,
        servicesHeadingRight: headingText.getBoundingClientRect().right,
        servicesHeadingBaseline: baseline.getBoundingClientRect().top - heading.getBoundingClientRect().top,
        entranceDistance: entrance.offsetHeight,
        processTop: top(process), steps: steps.map(step => ({ top: top(step), height: step.offsetHeight })),
        quizTop: top(quiz), closingTop: top(closing), end: top(root) + root.offsetHeight,
      }
    }
    const update = () => {
      pending = 0
      frame.current = sampleJourneyFrame(window.scrollY, layout)
      root.style.setProperty('--journey-visibility', String(frame.current.visible))
      root.style.setProperty('--journey-x', `${(frame.current.x + 1) * 50}%`)
      root.style.setProperty('--journey-y', `${(1 - frame.current.y) * 50}%`)
      root.style.setProperty('--journey-width', `${frame.current.scale * 100}%`)
      root.style.setProperty('--journey-finish', String(frame.current.finish))
      root.style.setProperty('--journey-services-surface', String(frame.current.servicesSurface))
      steps.forEach((step, index) => {
        const relative = layout.steps[index].top - window.scrollY
        step.dataset.active = String(relative < layout.viewportHeight * 0.58 && relative + layout.steps[index].height > layout.viewportHeight * 0.35)
      })
    }
    const requestUpdate = () => { if (!pending) pending = requestAnimationFrame(update) }
    const refresh = () => { measure(); requestUpdate() }
    measure()
    update()
    const observer = new ResizeObserver(refresh)
    for (const element of [root, heading, headingText, entrance, process, quiz, closing]) observer.observe(element)
    window.addEventListener('scroll', requestUpdate, { passive: true })
    window.addEventListener('resize', refresh)
    // The preceding lazy hero can change length without changing this
    // element's own size. Its completed layout refresh also rebases us.
    ScrollTrigger.addEventListener('refresh', refresh)
    return () => {
      observer.disconnect()
      window.removeEventListener('scroll', requestUpdate)
      window.removeEventListener('resize', refresh)
      ScrollTrigger.removeEventListener('refresh', refresh)
      cancelAnimationFrame(pending)
      frame.current = { ...frame.current, visible: 0 }
    }
  }, [frame, interactive])

  return (
    <div className="home-journey" data-live={live} data-scroll={interactive} ref={rootRef}>
      {live && <JourneyVisual frame={frame} nearby={nearby} onFailure={() => setFailed(true)} />}

      <section className="journey-services" id="services" aria-labelledby="journey-services-heading">
        <header className="journey-services__header">
          <div className="container journey-services__heading-wrap">
            <div>
              <p className="eyebrow journey-kicker">01 / What moves you forward</p>
              <h2 id="journey-services-heading">{renderLines(services.headingLines)}<span className="journey-services__baseline" aria-hidden="true" /></h2>
            </div>
            <img className="journey-static-mark" src="/brand/wallace-shift-logo-black.svg" alt="" width="180" height="105" />
          </div>
        </header>
        <div className="journey-services__entrance" aria-hidden="true" />
        <JourneyServiceRows />
        <div className="container journey-services__links">
          {[services.detailLink, services.pricingLink].map(link => <PageLink href={link.href} key={link.href}>
            <span className="eyebrow">{link.eyebrow}</span><span>{link.label} <span aria-hidden="true">↗</span></span>
          </PageLink>)}
        </div>
        <div className="journey-services__clearance" aria-hidden="true" />
      </section>

      <section className="journey-process" id="approach" aria-labelledby="journey-process-heading">
        <div className="container">
          <header className="journey-process__header">
            <p className="eyebrow journey-kicker">02 / How the shift happens</p>
            <h2 id="journey-process-heading">{renderLines(approach.headingLines)}</h2>
          </header>
          <div className="journey-process__steps">
            {approach.steps.map((step, index) => <article className="journey-process__step" key={step.index}>
              <div className="journey-process__copy">
                <p className="journey-process__phase"><span>{step.index}</span>{processPhases[index]}</p>
                <h3>{step.title}</h3>
                <p>{step.description}</p>
                <div className={`journey-process__diagram journey-process__diagram--${index}`} aria-hidden="true"><i /><i /></div>
              </div>
            </article>)}
          </div>
          <PageLink href="/approach" className="journey-process__link">A closer look at our approach <span aria-hidden="true">↗</span></PageLink>
        </div>
      </section>

      <ShiftQuiz showSpotlight={false} />

      <div className="home-journey__closing">
        <div className="home-journey__still-water" aria-hidden="true"><img src="/brand/wallace-shift-logo-white.svg" alt="" width="240" height="140" /></div>
        <ContactCta sceneBackground />
        <SiteFooter />
      </div>
    </div>
  )
}
