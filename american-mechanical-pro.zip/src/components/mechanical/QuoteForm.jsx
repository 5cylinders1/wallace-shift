import { ArrowRight, Phone } from 'lucide-react';
import { serviceChoices } from '@/lib/mechanical-services';
import { useState } from 'react';
import { useServerFn } from '@tanstack/react-start';
import { submitQuote } from '@/lib/submit-quote';

export default function QuoteForm({ service, setService }) {
  const submit = useServerFn(submitQuote);
  const [state, setState] = useState('idle');
  async function onSubmit(event) {
    event.preventDefault();
    if (state === 'sending' || state === 'sent') return;
    const form = event.currentTarget;
    const data = Object.fromEntries(new FormData(form));
    const digits = data.phone.replace(/\D/g, '').length;
    if (data.name.trim().length < 2 || ![10, 11].includes(digits) || !/^[+\d().\s-]+$/.test(data.phone)) {
      setState('invalid');
      return;
    }
    setState('sending');
    try {
      const result = await submit({ data });
      if (!result?.received) throw new Error('Request not saved');
      form.reset();
      setService('');
      setState('sent');
    } catch {
      setState('error');
    }
  }
  return <section id="quote" className="am-quote"><div className="am-shell am-quote-grid">
    <div><p className="am-kicker"><span/> REQUEST A QUOTE</p><h2>Tell us what you need.</h2><p>Share a few details about the job so we can get in touch and talk through your options.</p><a href="tel:+19137258376"><Phone size={16}/> Prefer to call? (913) 725-8376</a></div>
    {state === 'sent' ? <div className="am-form" role="status"><h3 className="text-xl font-bold">Quote request received</h3><p>Thank you. Our team will use the contact details you provided to follow up.</p><button type="button" className="am-btn am-primary mt-4" onClick={()=>setState('idle')}>Send another request</button></div> : <form className="am-form" onSubmit={onSubmit}><div aria-hidden="true" hidden><label>Leave blank<input name="website" tabIndex={-1} autoComplete="off"/></label></div><div className="am-fields">
      <label>Full name<input name="name" autoComplete="name" required maxLength={100}/></label>
      <label>Phone number<input name="phone" type="tel" autoComplete="tel" required maxLength={30}/></label>
      <label>Email (optional)<input name="email" type="email" autoComplete="email" maxLength={254}/></label>
      <label>ZIP code<input name="zip" inputMode="numeric" autoComplete="postal-code" required pattern="[0-9]{5}" maxLength={5}/></label>
      <label>Service<select name="service" required value={service} onChange={event=>setService(event.target.value)}><option value="">Select a service</option>{serviceChoices.map(item=><option key={item}>{item}</option>)}</select></label>
      <label>Property type<select name="property" required><option value="">Select property type</option><option>Home</option><option>Business</option></select></label>
      <label className="am-wide">What can we help with? (optional)<textarea name="details" rows={3} maxLength={1500}/></label>
    </div><button type="submit" className="am-btn am-primary" disabled={state === 'sending'}>{state === 'sending' ? 'Sending…' : 'Send Quote Request'} <ArrowRight size={17}/></button>
    {state === 'error' && <p role="alert">We couldn’t save your request. Try again or call (913) 725-8376.</p>}
    {state === 'invalid' && <p role="alert">Please enter your full name and a valid US phone number.</p>}
    <p>For urgent service, please call rather than using this form.</p></form>}
  </div></section>;
}