import { Link } from '@tanstack/react-router';
import { ArrowRight, ChevronRight, Phone } from 'lucide-react';
import SiteHeader from '@/components/mechanical/SiteHeader';
import SiteFooter from '@/components/mechanical/SiteFooter';
import { areaPages, servicePages } from '@/lib/mechanical-services';
import siteStyles from '@/components/mechanical/site.css?url';

export function detailHead(title, description) {
  return { meta: [{ title }, { name: 'description', content: description }], links: [{ rel: 'stylesheet', href: siteStyles }, { rel: 'stylesheet', href: 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap' }] };
}

export default function DetailPage({ name, headline, intro, blocks, service, area, brands, extra }) {
  const quoteText = area ? 'Request a Local Quote' : service === 'Heating & Cooling' || service === 'Water Heaters' ? 'Request a Quote' : 'Ask About Availability';
  return <div className="am-site">
    <SiteHeader />
    <main>
      <section className="am-hero am-detail-hero"><div className="am-shell">
        <nav aria-label="Breadcrumb"><Link to="/">Home</Link><ChevronRight size={14}/><Link to="/" hash={area ? 'locations' : 'services'}>{area ? 'Service Areas' : 'Services'}</Link><ChevronRight size={14}/><span aria-current="page">{name}</span></nav>
        <h1>{headline}</h1><p className="am-intro">{intro}</p>
        <div className="am-actions"><Link to="/" hash="quote" search={service ? { service } : {}} className="am-btn am-primary">{quoteText}<ArrowRight size={18}/></Link><a className="am-btn am-outline" href="tel:+19137258376"><Phone size={17}/> Call (913) 725-8376</a></div>
      </div></section>
      <section className="am-shell am-section"><p className="am-kicker"><span/> PLAN YOUR SERVICE</p><h2>{area ? 'What to know before you call' : 'What to expect'}</h2>
        <div className="am-services">{blocks.map(([heading, copy]) => <article className="am-card am-detail-card" key={heading}><h3>{heading}</h3><p>{copy}</p></article>)}</div>
        {extra && <p className="am-section-intro">{extra}</p>}
        {brands}
      </section>
      <section className="am-detail-related"><div className="am-shell"><h2>{area ? 'Explore local services' : 'Explore services and coverage'}</h2><div className="am-detail-links">{[...(area ? servicePages.slice(0, 2) : servicePages), ...areaPages].filter(([, label]) => label !== name).map(([path, label]) => <Link key={path} to={path}>{label}<ArrowRight size={16}/></Link>)}<Link to="/" hash="locations">View All Service Areas<ArrowRight size={16}/></Link></div></div></section>
    </main>
    <SiteFooter />
  </div>;
}