import { ArrowUpRight } from 'lucide-react';
import { Image } from '@/components/ui/image';

const manufacturers = [
  { name: 'Lennox', logo: 'https://www.lennox.com/application/themes/lennox/assets/global/lennox_logo.svg', website: 'https://www.lennox.com/residential/', description: 'Lennox makes home heating and cooling systems, including gas furnaces, central air conditioners and heat pumps.', equipment: 'Air handlers, indoor coils and smart thermostats' },
  { name: 'Carrier', logo: 'https://brandportal.carrier.com/m/99b434eac013f6f/webimage-carrier_logo_rgb.png', website: 'https://www.carrier.com/us/en/residential/', description: 'Carrier makes central and ductless systems for home heating and cooling, including air conditioners, furnaces and heat pumps.', equipment: 'Air handlers, evaporator coils and system controls' },
  { name: 'YORK', logo: 'https://york.bosch-hcgroup.com/-/media/project/jci-global/york-sites/united-states-york/brand-logos/york_full_color_logo.png?la=en&h=95&w=391&hash=426A3A014690E6975F7AEEA37AF336BE', website: 'https://york.bosch-hcgroup.com/residential-equipment', description: 'YORK makes residential and light commercial HVAC equipment, from split system heat pumps to packaged units.', equipment: 'Evaporator coils, air handlers and replacement parts' },
  { name: 'Rheem', logo: 'https://files.rheem.com/blobazrheem/wp-content/uploads/sites/2/logo.svg', website: 'https://www.rheem.com/', description: 'Rheem makes air conditioners, furnaces and heat pumps, as well as tank, tankless and heat pump water heaters.', equipment: 'Air handlers, cooling coils and system controls' },
];

export default function HvacBrands() {
  return <section aria-labelledby="hvac-brands" className="mt-12 border-t border-border pt-9">
    <p className="am-kicker"><span/> EQUIPMENT &amp; PARTS</p>
    <h2 id="hvac-brands">HVAC brands to know</h2>
    <p className="am-section-intro">Comparing new systems or looking for a replacement part? Start with what each manufacturer makes, then check compatibility for your model.</p>
    <ul className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {manufacturers.map(({ name, logo, website, description, equipment }) => <li className="am-card am-detail-card" key={name}>
        <div className="mb-4 flex h-14 items-center"><Image src={logo} alt="" fittingType="fit" loading="lazy" className="h-12 w-36 max-w-full object-contain object-left" /></div>
        <h3>{name}</h3>
        <p>{description}</p>
        <p className="!mb-4"><strong>Parts &amp; components:</strong> {equipment}</p>
        <a href={website}>Visit {name} <ArrowUpRight size={16} aria-hidden="true" /></a>
      </li>)}
    </ul>
  </section>;
}