import { Fan, MapPin, Phone, Zap } from 'lucide-react';
import { Link } from '@tanstack/react-router';

export default function SiteHeader() {
  return <header className="am-header" id="top">
    <div className="am-top"><div className="am-shell am-top-inner"><span><MapPin size={13}/> Serving Greater Kansas City</span><a href="tel:+19137258376"><Zap size={13}/> Emergency service? Call now</a></div></div>
    <div className="am-shell am-nav"><Link to="/" hash="top" className="am-brand" aria-label="American Mechanical KC home"><span className="am-mark"><Fan size={24}/></span><span>American Mechanical<small>K A N S A S &nbsp; C I T Y</small></span></Link><nav aria-label="Main navigation"><Link to="/" hash="services">Services</Link><Link to="/" hash="locations">Service Areas</Link><Link to="/" hash="reviews">Reviews</Link><Link to="/blog">Blog</Link><Link to="/" hash="quote">Request a Quote</Link></nav><a className="am-nav-phone" href="tel:+19137258376"><Phone size={16}/><span>(913) 725-8376</span></a></div>
  </header>;
}