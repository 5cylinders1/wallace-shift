import { ArrowRight, ArrowUpRight, Droplets, Flame, Hammer, House, Phone, Refrigerator, Snowflake, Star } from 'lucide-react';
import { Link } from '@tanstack/react-router';
import { serviceChoices, servicePages } from '@/lib/mechanical-services';
import ServiceAreas from '@/components/mechanical/ServiceAreas';

const google = 'https://www.google.com/maps/place/American+Mechanical+KC/data=!4m2!3m1!1s0x87c0f141a1530f4b:0x963330f9b1245dae';
const items = [
  [Snowflake, 'Keep your property comfortable year-round with furnace and air conditioner installation, replacement, and repair.', 'Explore Heating & Cooling', servicePages[0][0]],
  [Flame, 'Replace an aging or failed water heater. We’ll talk through your hot water needs and help you choose the right size.', 'Explore Water Heater Services', servicePages[1][0]],
  [Droplets, 'Interested in whole-house water filtration? Tell us about your water concerns and ask about availability.', 'Ask About Filtration'],
  [Refrigerator, 'Ask about selecting, replacing, or servicing an appliance at your property.', 'Explore Appliance Services', servicePages[2][0]],
  [Hammer, 'Tell us about your kitchen, bath, or other indoor remodeling project and ask about scope.', 'Explore Interior Remodels', servicePages[3][0]],
  [House, 'Planning an exterior update? Ask what’s available for your property and timeline.', 'Explore Exterior Remodels', servicePages[4][0]],
];

export default function ServiceSections({ onSelect }) {
  return <>
    <section id="services" className="am-section am-shell"><p className="am-kicker"><span/> WHAT WE DO</p><h2>How can we help?</h2><p className="am-section-intro">We focus on work that lasts and fair pricing, whether it’s for your home or business.</p>
      <div className="am-services">{items.map(([Icon, text, cta, page], i)=><article className="am-card" key={cta}><div className="am-card-top"><Icon size={25}/><span>{i < 2 ? `0${i+1}` : 'ASK ABOUT AVAILABILITY'}</span></div><h3>{serviceChoices[i]}</h3><p>{text}</p>{page ? <Link to={page}>{cta}<ArrowRight size={16}/></Link> : <a href="#quote" onClick={()=>onSelect(serviceChoices[i])}>{cta}<ArrowRight size={16}/></a>}</article>)}</div>
    </section>
    <section className="am-urgent"><div className="am-shell am-urgent-row"><div><p className="am-kicker"><span/> EMERGENCY SERVICE</p><h2>Need help now?</h2><p>Call to describe the issue and check the next available service time. Don’t wait on the quote form.</p></div><a className="am-btn am-primary" href="tel:+19137258376"><Phone size={18}/> Call (913) 725-8376</a></div></section>
    <section id="reviews" className="am-shell am-section"><p className="am-kicker"><span/> FROM KANSAS CITY CUSTOMERS</p><h2>What customers say</h2><p className="am-section-intro">Rated <strong>4.6 out of 5</strong> from 37 reviews on Google.</p><div className="am-reviews">
    {[['Jen Sol','Great service and very knowledgeable of his craft.'],['Evan Johnson','Eddie at American Mechanical KC came through big time — he had the exact part we needed and made sure we were taken care of.']].map(([name,quote])=><figure key={name} className="am-card am-review"><div aria-label="5 stars">{Array.from({length:5},(_,i)=><Star key={i} size={15} fill="currentColor"/>)}</div><blockquote>“{quote}”</blockquote><figcaption>{name} <span>· Google review excerpt</span></figcaption></figure>)}
    </div><a className="am-review-link" href={google} target="_blank" rel="noreferrer">Read all reviews on Google <ArrowUpRight size={16}/></a></section>
    <ServiceAreas />
  </>;
}