import { Link } from '@tanstack/react-router';
import { ArrowRight, ChevronRight } from 'lucide-react';
import { detailHead } from '@/components/mechanical/DetailPage';
import SiteHeader from '@/components/mechanical/SiteHeader';
import SiteFooter from '@/components/mechanical/SiteFooter';
import { getPost } from '@/lib/blog/posts';

export function articleOptions(slug) {
  const post = getPost(slug);
  return { head: () => detailHead(post.title, post.description), component: () => <BlogArticle post={post} /> };
}

export default function BlogArticle({ post }) {
  return <div className="am-site">
    <SiteHeader />
    <main><article aria-labelledby="article-title">
      <header className="am-hero am-detail-hero"><div className="am-shell">
        <nav aria-label="Breadcrumb"><Link to="/">Home</Link><ChevronRight size={14}/><Link to="/blog">Blog</Link><ChevronRight size={14}/><span aria-current="page">{post.category}</span></nav>
        <h1 id="article-title">{post.title}</h1><p className="am-intro">American Mechanical KC</p>
      </div></header>
      <div className="am-shell am-section"><div className="mx-auto max-w-[700px] space-y-8 text-[17px] leading-relaxed">
        <p className="text-lg font-medium sm:text-xl">{post.intro}</p>
        {post.sections.map(([heading, copy]) => <section key={heading}><h2 className="!mt-0 !text-[clamp(24px,3vw,32px)]">{heading}</h2><p className="mt-3 opacity-90">{copy}</p></section>)}
        <aside aria-label="Water heater service" className="am-card"><h3 className="!mt-0">Need help with your water heater?</h3><p>American Mechanical KC serves homes and businesses across Greater Kansas City.</p><div className="flex flex-wrap gap-x-6 gap-y-3"><Link to="/water-heater-installation">Explore Water Heater Services <ArrowRight size={16}/></Link><Link to="/" search={{ service: 'Water Heaters' }} hash="quote">Request a Quote <ArrowRight size={16}/></Link></div></aside>
      </div></div>
    </article>
    <section className="am-detail-related"><div className="am-shell"><h2>Keep reading</h2><div className="am-detail-links">{post.related.map(getPost).map(item => <Link to={'/blog/' + item.slug} key={item.slug}>{item.title}<ArrowRight size={16}/></Link>)}</div></div></section></main>
    <SiteFooter />
  </div>;
}