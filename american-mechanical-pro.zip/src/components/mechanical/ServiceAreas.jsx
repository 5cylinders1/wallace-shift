import { Link } from '@tanstack/react-router';
import ServiceAreaIllustration from '@/components/mechanical/ServiceAreaIllustration';
import { ArrowRight } from 'lucide-react';
import { areaPages } from '@/lib/mechanical-services';
import { serviceAreas } from '@/lib/service-areas';

const areaLinks = new Map(areaPages.map(([path, name]) => [name, path]));

export default function ServiceAreas() {
  return <section id="locations" className="am-detail-related" aria-labelledby="service-areas-title">
    <div className="am-shell">
      <p className="am-kicker"><span/> SERVICE AREAS</p>
      <h2 id="service-areas-title">Serving Greater Kansas City</h2>
      <p className="am-section-intro">We serve communities on both sides of the state line. Include your ZIP code when you request a quote so we can confirm availability for your address.</p>
      <figure className="mt-6 max-w-5xl overflow-hidden rounded-lg border border-border bg-background shadow-sm">
        <div className="aspect-[5/4] sm:aspect-[55/24]"><ServiceAreaIllustration /></div>
        <figcaption className="flex items-center gap-3 border-t border-border px-4 py-3 text-sm text-muted-foreground sm:px-5">
          <span aria-hidden="true" className="size-3.5 shrink-0 rounded-full border border-blue-700 bg-blue-100" />
          <span>The shaded circle shows our general service area, not an exact boundary.</span>
        </figcaption>
      </figure>
      <details className="mt-3">
        <summary className="w-fit cursor-pointer py-2 text-sm font-semibold">View all {serviceAreas.reduce((count, { cities }) => count + cities.length, 0)} service areas</summary>
        <div className="mt-2 grid gap-4 lg:grid-cols-[3fr_2fr]">
        {serviceAreas.map(({ state, abbreviation, cities }) => <div className="am-card am-detail-card" key={state}>
          <h3>{state}</h3>
          <ul aria-label={`${state} service areas`} className={`mt-3 columns-2 gap-4 text-sm leading-snug ${abbreviation === 'MO' ? 'sm:columns-3' : ''}`}>
            {cities.map(([city]) => {
              const name = `${city}, ${abbreviation}`;
              const path = areaLinks.get(name);
              return <li className="break-inside-avoid py-1.5" key={name}>{path ? <Link to={path}><span>{name}</span><ArrowRight size={14} aria-hidden="true"/></Link> : name}</li>;
            })}
          </ul>
        </div>)}
        </div>
      </details>
    </div>
  </section>;
}