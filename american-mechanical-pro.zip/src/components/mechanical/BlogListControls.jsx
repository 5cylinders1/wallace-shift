import { Link } from '@tanstack/react-router';
import { ChevronLeft, ChevronRight } from 'lucide-react';

export default function BlogListControls({ categories, category, perPage, perPageOptions, onCategory, onPerPage }) {
  return <div className="am-card !flex-row flex-wrap gap-4">
    <label className="flex min-w-0 flex-1 basis-[200px] flex-col gap-1.5 text-sm font-semibold" htmlFor="blog-category">Category
      <select id="blog-category" className="min-h-11 w-full rounded-md border border-input bg-background px-3" value={category ?? ''} onChange={event => onCategory(event.target.value || undefined)}>
        <option value="">All categories</option>{categories.map(item => <option key={item}>{item}</option>)}
      </select>
    </label>
    <label className="flex flex-col gap-1.5 text-sm font-semibold" htmlFor="blog-per-page">Posts per page
      <select id="blog-per-page" className="min-h-11 rounded-md border border-input bg-background px-3" value={perPage} onChange={event => onPerPage(Number(event.target.value))}>
        {perPageOptions.map(size => <option key={size} value={size}>{size}</option>)}
      </select>
    </label>
  </div>;
}

export function BlogPagination({ page, pageCount, search }) {
  if (pageCount <= 1) return null;
  const link = 'inline-flex min-h-11 min-w-11 items-center justify-center gap-1 rounded-md border border-input px-3 text-sm font-semibold hover:bg-muted';
  const current = 'inline-flex min-h-11 min-w-11 items-center justify-center rounded-md border border-primary bg-primary px-3 text-sm font-semibold text-primary-foreground';
  const pageSearch = number => ({ ...search, page: number === 1 ? undefined : number });
  return <nav aria-label="Blog pagination" className="mt-8 flex flex-wrap items-center gap-2">
    {page > 1 && <Link to="/blog" hash="blog-posts" search={pageSearch(page - 1)} className={link}><ChevronLeft size={16} /> Previous</Link>}
    {Array.from({ length: pageCount }, (_, i) => i + 1).map(number => number === page
      ? <span key={number} aria-current="page" aria-label={`Page ${number}`} className={current}>{number}</span>
      : <Link key={number} to="/blog" hash="blog-posts" search={pageSearch(number)} className={link} aria-label={`Page ${number}`}>{number}</Link>)}
    {page < pageCount && <Link to="/blog" hash="blog-posts" search={pageSearch(page + 1)} className={link}>Next <ChevronRight size={16} /></Link>}
  </nav>;
}