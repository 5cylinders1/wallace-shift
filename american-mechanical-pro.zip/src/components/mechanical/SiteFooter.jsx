import { Link } from '@tanstack/react-router';

export default function SiteFooter() {
  return <footer className="am-footer"><div className="am-shell am-foot-grid"><div><strong>American Mechanical KC</strong><p>Serving homes and businesses across Greater Kansas City.</p><Link to="/blog" className="inline-block pt-1">Blog</Link></div><div><a href="tel:+19137258376">(913) 725-8376</a><br/><a href="mailto:info@amechkc.com">info@amechkc.com</a></div><div><a href="https://www.google.com/maps/place/American+Mechanical+KC/data=!4m2!3m1!1s0x87c0f141a1530f4b:0x963330f9b1245dae" target="_blank" rel="noreferrer">1025 Winchester Ave, Kansas City, MO 64126</a><p>Office hours: Mon–Fri, 9 AM–5 PM</p></div></div></footer>;
}