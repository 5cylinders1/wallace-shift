import { ArrowDownRight, ArrowRight, MapPin, Phone, Star } from 'lucide-react';
import { Image } from '@/components/ui/image';

export default function MechanicalHero() {
  return <>
    <section className="am-hero"><div className="am-shell am-hero-grid"><div className="am-hero-copy">
      <p className="am-kicker"><span/> KANSAS CITY HEATING, COOLING & HOT WATER</p>
      <h1>Comfort you<br className="am-desktop"/> can <em>count on.</em></h1>
      <p className="am-intro">HVAC and water heater installation for homes and businesses across Greater Kansas City. Get a quote for your next project, or call when it can’t wait.</p>
      <div className="am-actions"><a className="am-btn am-primary" href="#quote">Request a Quote <ArrowRight size={18}/></a><a className="am-btn am-outline" href="tel:+19137258376"><Phone size={17}/> Emergency Service</a></div>
      <a className="am-hero-review" href="#reviews"><span aria-hidden="true">{Array.from({length:5},(_,i)=><Star key={i} size={15} fill="currentColor"/>)}</span><strong>4.6</strong> <span>from 37 Google reviews</span></a>
    </div><figure className="am-hero-figure"><Image src="https://media.base44.com/images/public/6b0459b0732a6b4f82d4372b/74a9cb1883f056167de2b32a38d8d2a0_generated_82e2d1a0.png" className="am-hero-image" loading="eager" fetchPriority="high" alt="Illustration of a clean mechanical room with HVAC equipment, copper piping, and a water heater"/><figcaption><span><MapPin size={15}/> LOCALLY BASED IN KANSAS CITY</span><ArrowDownRight size={19}/></figcaption></figure></div></section>
  </>;
}