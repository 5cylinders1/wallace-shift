import { createFileRoute } from '@tanstack/react-router';
import DetailPage, { detailHead } from '@/components/mechanical/DetailPage';

export const Route = createFileRoute('/services/interior-remodels')({
  head: () => detailHead('Interior Remodels in Kansas City | American Mechanical KC', 'Discuss a kitchen, bath or other interior remodel in Greater Kansas City. Share what you want to change, your timeline and your project priorities.'),
  component: InteriorRemodels,
});

function InteriorRemodels() {
  return <DetailPage name="Interior Remodels" headline="Interior remodeling inquiries" service="Interior Remodels"
    intro="Whether you’re updating a kitchen, reworking a bathroom, or changing how several rooms fit together, tell us what isn’t working today and ask if the project fits our current scope."
    blocks={[
      ['Start with the layout', 'Tell us what needs to stay, what can move, and how you use the room. Moving a sink, appliance, or wall is a different project from keeping the layout and updating finishes.'],
      ['Plan around daily use', 'If it’s your only bathroom or you need the kitchen usable by a certain date, say so early. That can affect which work should happen first and how the job is scheduled.'],
      ['List your priorities', 'Share your rough budget and distinguish must-haves from nice-to-haves. Mention any ventilation, heating, or hot water changes you want considered alongside the remodel.'],
    ]} />;
}