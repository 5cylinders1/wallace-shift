import { createFileRoute } from '@tanstack/react-router';
import { articleOptions } from '@/components/mechanical/BlogArticle';
export const Route = createFileRoute('/blog/how-long-do-water-heaters-last')(articleOptions('how-long-do-water-heaters-last'));