import { createFileRoute } from '@tanstack/react-router';
import { articleOptions } from '@/components/mechanical/BlogArticle';
export const Route = createFileRoute('/blog/water-heater-permits-and-expansion-tanks')(articleOptions('water-heater-permits-and-expansion-tanks'));