import { createFileRoute } from '@tanstack/react-router';
import { articleOptions } from '@/components/mechanical/BlogArticle';
export const Route = createFileRoute('/blog/water-heater-leaking-rust-sediment')(articleOptions('water-heater-leaking-rust-sediment'));