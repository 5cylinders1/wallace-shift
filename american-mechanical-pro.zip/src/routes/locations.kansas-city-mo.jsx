import { createFileRoute } from '@tanstack/react-router';
import DetailPage, { detailHead } from '@/components/mechanical/DetailPage';

export const Route = createFileRoute('/locations/kansas-city-mo')({
  head: () => detailHead('HVAC & Water Heaters in Kansas City, MO | American Mechanical KC', 'Find HVAC and water heater service for Kansas City, Missouri homes and businesses. Check availability by ZIP or call the local team for urgent service.'),
  component: KansasCity,
});

function KansasCity() {
  return <DetailPage name="Kansas City, MO" headline="HVAC and water heater service in Kansas City, MO" area
    extra={<>Planning a replacement within city limits? See <a className="underline" href="https://www.kcmo.gov/city-hall/departments/city-planning-development/electrical-plumbing-and-mechanical-permits">Kansas City’s plumbing and mechanical permit guidance</a> and ask who will handle any required permits before work starts.</>}
    intro="American Mechanical KC is based on Winchester Avenue in Kansas City, Missouri. We serve homes and businesses throughout the metro. Include your ZIP code so we can confirm service for your address."
    blocks={[
      ['For Kansas City homes', 'If you’re replacing equipment in a basement or utility closet, tell us about stairs, narrow doors, and where the existing unit sits. Access can affect equipment selection and installation.'],
      ['For Kansas City businesses', 'Let us know if a heating, cooling, or hot water outage is affecting your business hours. Include whether the unit serves one suite or multiple spaces, and who can provide access.'],
      ['Call when it can’t wait', 'For a system outage or an active water heater leak, call (913) 725-8376 to check the next available service time instead of waiting for an online response.'],
    ]} />;
}