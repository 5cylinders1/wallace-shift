import { createFileRoute } from '@tanstack/react-router';
import SiteFooter from '@/components/mechanical/SiteFooter';
import { serviceChoices } from '@/lib/mechanical-services';
import SiteHeader from '@/components/mechanical/SiteHeader';
import MechanicalHero from '@/components/mechanical/MechanicalHero';
import ServiceSections from '@/components/mechanical/ServiceSections';
import QuoteForm from '@/components/mechanical/QuoteForm';
import { useState } from 'react';
import siteStyles from '@/components/mechanical/site.css?url';

export const Route = createFileRoute('/')({
  head: () => ({ meta: [{ title: 'American Mechanical KC | HVAC & Water Heater Installation' }, { name: 'description', content: 'Kansas City HVAC and water heater installation for homes and businesses. Request a quote or call American Mechanical KC for urgent service.' }], links: [{ rel: 'stylesheet', href: siteStyles }, { rel: 'stylesheet', href: 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap' }] }),
  validateSearch: search => serviceChoices.includes(search.service) ? { service: search.service } : {},
  component: Home,
});

function Home() {
  const { service } = Route.useSearch();
  return <HomeContent key={service ?? ''} initialService={service ?? ''} />;
}

function HomeContent({ initialService }) {
  const [service, setService] = useState(initialService);
  return <div className="am-site">
    <SiteHeader />
    <main><MechanicalHero /><ServiceSections onSelect={setService} /><QuoteForm service={service} setService={setService} /></main>
    <SiteFooter />
  </div>;
}