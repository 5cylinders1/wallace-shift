import { createFileRoute } from '@tanstack/react-router';
import { articleOptions } from '@/components/mechanical/BlogArticle';
export const Route = createFileRoute('/blog/water-heater-replacement-cost-and-time')(articleOptions('water-heater-replacement-cost-and-time'));