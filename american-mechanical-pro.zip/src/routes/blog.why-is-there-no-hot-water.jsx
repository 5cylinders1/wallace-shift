import { createFileRoute } from '@tanstack/react-router';
import { articleOptions } from '@/components/mechanical/BlogArticle';
export const Route = createFileRoute('/blog/why-is-there-no-hot-water')(articleOptions('why-is-there-no-hot-water'));