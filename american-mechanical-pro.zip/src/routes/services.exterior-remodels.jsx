import { createFileRoute } from '@tanstack/react-router';
import DetailPage, { detailHead } from '@/components/mechanical/DetailPage';

export const Route = createFileRoute('/services/exterior-remodels')({
  head: () => detailHead('Exterior Remodels in Kansas City | American Mechanical KC', 'Ask about exterior remodeling in Greater Kansas City. Share the part of the property you want to update and any access or weather-related concerns.'),
  component: ExteriorRemodels,
});

function ExteriorRemodels() {
  return <DetailPage name="Exterior Remodels" headline="Exterior remodeling inquiries" service="Exterior Remodels"
    intro="Thinking about an exterior update? Tell us which part of the property you want to improve, whether the goal is to address wear or change the look, and ask about current project availability."
    blocks={[
      ['Describe the existing exterior', 'Identify the side of the building and the material you want to keep or replace. Note visible wear or water staining so the project discussion can address more than appearance.'],
      ['Flag access and timing', 'Mention tight gates, steep grades, or other access limits. If a particular event or season drives your deadline, share it so outdoor work can be planned around the weather.'],
      ['Confirm scope before committing', 'Ask which parts of the project are in scope, who handles any applicable approvals, and what needs to be decided before pricing can be finalized.'],
    ]} />;
}