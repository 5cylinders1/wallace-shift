import { createFileRoute } from '@tanstack/react-router';
import { articleOptions } from '@/components/mechanical/BlogArticle';
export const Route = createFileRoute('/blog/best-water-heater-temperature')(articleOptions('best-water-heater-temperature'));