import { createFileRoute } from '@tanstack/react-router';
import { articleOptions } from '@/components/mechanical/BlogArticle';
export const Route = createFileRoute('/blog/is-a-tankless-water-heater-worth-it')(articleOptions('is-a-tankless-water-heater-worth-it'));