import { createFileRoute } from '@tanstack/react-router';
import { articleOptions } from '@/components/mechanical/BlogArticle';
export const Route = createFileRoute('/blog/best-type-of-water-heater')(articleOptions('best-type-of-water-heater'));