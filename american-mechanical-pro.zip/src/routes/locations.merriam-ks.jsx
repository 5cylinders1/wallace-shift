import { createFileRoute } from '@tanstack/react-router';
import DetailPage, { detailHead } from '@/components/mechanical/DetailPage';

export const Route = createFileRoute('/locations/merriam-ks')({
  head: () => detailHead('HVAC & Water Heater Service in Merriam, KS | American Mechanical KC', 'Get help with water heater replacement, furnace and AC service in Merriam, Kansas. Find out what to share when requesting a quote.'),
  component: Merriam,
});

function Merriam() {
  return <DetailPage name="Merriam, KS" headline="Water heaters and HVAC in Merriam, KS" area
    extra={<>Moving equipment or changing plumbing or mechanical systems as part of a remodel? Check <a className="underline" href="https://www.merriam.org/Government/Departments/Community-Development/Building-Permits">Merriam’s building permit guidance</a> before finalizing the scope.</>}
    intro="Our Kansas City team travels to Merriam for water heater installation and heating and cooling work. Request a visit at your property and include your ZIP so we can confirm coverage and scheduling."
    blocks={[
      ['Replacing a water heater in Merriam', 'Start with the number of people or fixtures that rely on hot water. If you’re finishing a basement or moving the heater, mention the proposed location before choosing a unit.'],
      ['Planning heating and cooling work', 'If you’re upgrading a furnace or AC, note whether the current system leaves any rooms uncomfortable. If you’re booking maintenance instead, share when the system was last serviced.'],
      ['Preparing for your appointment', 'Keep the equipment label handy if you can read it safely. For rentals or shared buildings, tell us who can approve the work and arrange entry to the mechanical room.'],
    ]} />;
}