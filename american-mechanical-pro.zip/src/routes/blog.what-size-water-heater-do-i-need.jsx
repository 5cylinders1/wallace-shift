import { createFileRoute } from '@tanstack/react-router';
import { articleOptions } from '@/components/mechanical/BlogArticle';
export const Route = createFileRoute('/blog/what-size-water-heater-do-i-need')(articleOptions('what-size-water-heater-do-i-need'));