import { createFileRoute, Link } from '@tanstack/react-router';
import DetailPage, { detailHead } from '@/components/mechanical/DetailPage';

export const Route = createFileRoute('/water-heater-installation')({
  head: () => detailHead('Kansas City Water Heater Installation | American Mechanical KC', 'Request water heater installation, replacement or a repair assessment in Greater Kansas City. Get help choosing the right size for your property.'),
  component: WaterHeaterInstallation,
});

function WaterHeaterInstallation() {
  return <DetailPage name="Water Heaters" headline="Water heater installation and replacement" service="Water Heaters"
    extra={<>Planning a replacement? Browse our <Link to="/blog" className="underline">water heater guides</Link> for help comparing types, sizing and installation costs.</>}
    intro="Running out of hot water or replacing an older unit? We help Kansas City homeowners and businesses choose a water heater that suits their daily use and the space it needs to fit."
    blocks={[
      ['Choose the right size', 'Think about how many fixtures need hot water at once and whether demand has changed. Share the current unit’s size and whether it uses gas or electricity, if you know.'],
      ['Repair or replace?', 'No hot water doesn’t always mean the heater needs replacing. Tell us what changed, whether the water gets warm at all, and whether you can see water near the unit. If it’s leaking now, call instead of waiting for a quote.'],
      ['Plan the installation', 'We’ll review access, hookups, and any installation changes before recommending a replacement. Ask what’s included, whether the old unit will be removed, and how long your hot water may be off.'],
    ]} />;
}