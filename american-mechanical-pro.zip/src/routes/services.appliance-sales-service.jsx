import { createFileRoute } from '@tanstack/react-router';
import DetailPage, { detailHead } from '@/components/mechanical/DetailPage';

export const Route = createFileRoute('/services/appliance-sales-service')({
  head: () => detailHead('Appliance Sales & Service in Kansas City | American Mechanical KC', 'Ask American Mechanical KC about appliance sales or service. Share your appliance type, model number and what you need to confirm availability.'),
  component: Appliances,
});

function Appliances() {
  return <DetailPage name="Appliance Sales & Service" headline="Appliance sales and service" service="Appliance Sales & Service"
    intro="Need to replace an appliance or find out if the one you have can be repaired? Ask American Mechanical KC which appliance types and services are currently available in your ZIP code."
    blocks={[
      ['For a service inquiry', 'Include the brand, model number, approximate age, and any error code. Describe what the appliance still does and exactly when the problem occurs.'],
      ['For a replacement inquiry', 'Measure the opening and the tightest doorway on the way in. Note whether the appliance needs a gas, water, or electrical hookup so you can discuss what will fit.'],
      ['Confirm what’s included', 'Before you buy or book, ask whether delivery, installation, and removal of the old unit are available for your model and address.'],
    ]} />;
}