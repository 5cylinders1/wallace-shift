import { createFileRoute } from '@tanstack/react-router';
import DetailPage, { detailHead } from '@/components/mechanical/DetailPage';
import HvacBrands from '@/components/mechanical/HvacBrands';

export const Route = createFileRoute('/heating-and-cooling')({
  head: () => detailHead('Kansas City Heating & Cooling | American Mechanical KC', 'Get help with furnace and air conditioner installation, replacement, seasonal maintenance and urgent HVAC repairs in Greater Kansas City.'),
  component: HeatingAndCooling,
});

function HeatingAndCooling() {
  return <DetailPage name="Heating & Cooling" headline="Heating and cooling in Kansas City" service="Heating & Cooling" brands={<HvacBrands />}
    intro="From a furnace that can’t keep up to an air conditioner that won’t start, American Mechanical KC helps homeowners and businesses decide whether to repair, maintain, or replace their system."
    blocks={[
      ['New systems and replacements', 'Tell us about temperature differences between rooms, your current equipment, and your budget. We’ll review the property and explain which system options fit before you decide.'],
      ['Repairs and urgent HVAC calls', 'If your system has stopped working, call to check availability. Tell us whether the system runs at all, when the problem began, and whether you’ve noticed unusual sounds or poor airflow.'],
      ['Seasonal tune-ups', 'Schedule AC maintenance before cooling season or a furnace check before the first cold spell. If a room is consistently too hot or too cold, mention it when you book so the concern can be checked.'],
    ]} />;
}