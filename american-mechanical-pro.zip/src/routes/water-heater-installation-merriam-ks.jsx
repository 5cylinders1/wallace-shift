import { createFileRoute, redirect } from '@tanstack/react-router';

export const Route = createFileRoute('/water-heater-installation-merriam-ks')({
  beforeLoad: () => { throw redirect({ to: '/locations/merriam-ks', statusCode: 301 }); },
});