import { createFileRoute } from '@tanstack/react-router';
import { articleOptions } from '@/components/mechanical/BlogArticle';
export const Route = createFileRoute('/blog/water-heater-repair-or-replacement')(articleOptions('water-heater-repair-or-replacement'));