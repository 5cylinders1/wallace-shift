import { createFileRoute, Link } from '@tanstack/react-router';
import { ArrowRight, ChevronRight } from 'lucide-react';
import { detailHead } from '@/components/mechanical/DetailPage';
import SiteHeader from '@/components/mechanical/SiteHeader';
import SiteFooter from '@/components/mechanical/SiteFooter';
import { postGroups } from '@/lib/blog/posts';
import BlogListControls, { BlogPagination } from '@/components/mechanical/BlogListControls';

const categories = postGroups.map(group => group.category);
const perPageOptions = [5, 10, 20];
const defaultPerPage = perPageOptions[0];

export const Route = createFileRoute('/blog/')({
  validateSearch: search => {
    const page = Number(search.page);
    const perPage = Number(search.perPage);
    return {
      ...(categories.includes(search.category) ? { category: search.category } : {}),
      ...(perPageOptions.includes(perPage) && perPage !== defaultPerPage ? { perPage } : {}),
      ...(Number.isSafeInteger(page) && page > 1 ? { page } : {}),
    };
  },
  loaderDeps: ({ search }) => search,
  loader: ({ deps }) => {
    const matching = postGroups.filter(group => !deps.category || group.category === deps.category).flatMap(group => group.posts);
    const perPage = deps.perPage ?? defaultPerPage;
    const pageCount = Math.max(1, Math.ceil(matching.length / perPage));
    const page = Math.min(deps.page ?? 1, pageCount);
    const start = (page - 1) * perPage;
    return { posts: matching.slice(start, start + perPage), total: matching.length, page, pageCount, start, perPage };
  },
  head: () => detailHead('Water Heater Blog | American Mechanical KC', 'Read practical water heater guides from American Mechanical KC. Compare types and sizes, troubleshoot problems, and plan repairs or replacement.'),
  component: Blog,
});

function Blog() {
  const search = Route.useSearch();
  const navigate = Route.useNavigate();
  const { posts, total, page, pageCount, start, perPage } = Route.useLoaderData();
  const update = patch => navigate({ to: '/blog', search: previous => ({ ...previous, ...patch, page: undefined }), resetScroll: false });
  return <div className="am-site"><SiteHeader /><main>
    <header className="am-hero am-detail-hero"><div className="am-shell">
      <nav aria-label="Breadcrumb"><Link to="/">Home</Link><ChevronRight size={14}/><span aria-current="page">Blog</span></nav>
      <h1>Water heater advice</h1><p className="am-intro">What to do when the hot water runs out, what to look for in a replacement, and what to ask before you book.</p>
    </div></header>
    <section className="am-shell am-section" aria-labelledby="blog-posts">
      <h2 id="blog-posts" className="!mb-5 !mt-0 !text-[clamp(28px,4vw,42px)]">Browse articles</h2>
      <BlogListControls categories={categories} category={search.category} perPage={perPage} perPageOptions={perPageOptions}
        onCategory={category => update({ category })} onPerPage={size => update({ perPage: size === defaultPerPage ? undefined : size })} />
      <p className="am-section-intro" role="status">{total ? `Showing ${start + 1}–${start + posts.length} of ${total} ${total === 1 ? 'article' : 'articles'}` : 'No articles in this category.'}</p>
      <ul className="grid gap-3 pt-4">{posts.map(post => <li key={post.slug}><article className="am-card am-detail-card">
        <p className="am-kicker !mb-2 !mt-0 !text-xs">{post.category}</p>
        <h3><Link to={'/blog/' + post.slug} className="!text-inherit !text-[length:inherit]">{post.title}</Link></h3>
        <p className="!mb-3">{post.description}</p><Link to={'/blog/' + post.slug} aria-label={`Read: ${post.title}`}>Read article <ArrowRight size={16}/></Link>
      </article></li>)}</ul>
      <BlogPagination page={page} pageCount={pageCount} search={search} />
    </section>
  </main><SiteFooter /></div>;
}