import { createFileRoute } from '@tanstack/react-router';
import { articleOptions } from '@/components/mechanical/BlogArticle';
export const Route = createFileRoute('/blog/energy-efficient-water-heater-savings')(articleOptions('energy-efficient-water-heater-savings'));